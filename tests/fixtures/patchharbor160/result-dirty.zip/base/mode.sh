echo fixture
