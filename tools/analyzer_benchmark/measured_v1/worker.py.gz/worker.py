"""Operator-owned bootstrap for the shipped, real serial language adapter.

The production durable dispatcher still reports unavailable at this source
revision. This bootstrap explicitly calls its existing full adapter API; it
does not replace rankings, truncate text, or claim dispatcher integration.
"""
import hashlib
import json
import os
from pathlib import Path
import resource
import sys

sys.path.insert(0, sys.argv[1])
from specroad.analyzers import _model_session, language_text
from specroad.analyzers._values import digest
from specroad.analyzers.requests import AnalyzerRequest
from specroad.analyzers.worker import analyze_language
from specroad.analyzers.packages import create_package

request = AnalyzerRequest(sys.stdin.buffer.read())
loads = []
ranked = []
original_load = _model_session.load_reference_model
original_scores = language_text._scores

def load():
    model = original_load()
    loads.append(1)
    return model

def scores(model, text):
    ranked.append({'sha256': digest(text), 'codepoints': len(text)})
    return original_scores(model, text)

_model_session.load_reference_model = load
language_text._scores = scores
assessment = analyze_language(request)
package = create_package(request, [assessment.report])
raw = package.canonical_bytes
sys.stdout.buffer.write(raw)
sys.stdout.buffer.flush()
usage = resource.getrusage(resource.RUSAGE_SELF)
facts = {'pid': os.getpid(), 'ppid': os.getppid(), 'model_loads': len(loads),
         'ranked': ranked, 'user_seconds': usage.ru_utime,
         'system_seconds': usage.ru_stime, 'self_maxrss_kib': usage.ru_maxrss,
         'report_package_sha256': hashlib.sha256(raw).hexdigest()}
Path(MEASUREMENT_OUTPUT).write_text(json.dumps(facts, sort_keys=True) + '\n')

