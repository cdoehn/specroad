"""Offline setup of an immutable package and synthetic resource workload."""
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / 'packaging'))
from language_packaging.verify import verify_package
from language_packaging.build import wheel_files
from language_packaging.inventory import LANGID, NUMPY

TEXTS = [
 ('en', 'The application must preserve every original requirement and its revision history. An operator must be able to export the complete project and inspect every recorded change without a network connection.'),
 ('de', 'Die Anwendung muss jede ursprüngliche Anforderung und ihre Änderungshistorie erhalten. Eine Bedienperson muss das vollständige Projekt exportieren und jede gespeicherte Änderung ohne Netzwerkverbindung prüfen können.'),
 ('hi', 'अनुप्रयोग को प्रत्येक मूल आवश्यकता और उसका संशोधन इतिहास सुरक्षित रखना चाहिए। उपयोगकर्ता को पूरे प्रोजेक्ट का निर्यात करने और नेटवर्क कनेक्शन के बिना प्रत्येक दर्ज परिवर्तन की जाँच करने में सक्षम होना चाहिए।'),
 ('id', 'Aplikasi harus mempertahankan setiap persyaratan asli dan riwayat perubahannya. Pengguna harus dapat mengekspor seluruh proyek dan memeriksa setiap perubahan yang tercatat tanpa koneksi jaringan.'),
 ('pt', 'A aplicação deve preservar cada requisito original e o seu histórico de revisões. O operador deve poder exportar o projeto completo e verificar todas as alterações registadas sem uma ligação à rede.'),
 ('es', 'La aplicación debe conservar cada requisito original y su historial de revisiones. El usuario debe poder exportar el proyecto completo y revisar todos los cambios registrados sin una conexión de red.'),
 ('ru', 'Приложение должно сохранять каждое исходное требование и историю его изменений. Пользователь должен иметь возможность экспортировать весь проект и проверить каждое сохранённое изменение без подключения к сети.'),
 ('ja', 'アプリケーションは元の要件とその変更履歴をすべて保持しなければならない。利用者はネットワーク接続がなくてもプロジェクト全体を出力し、保存された変更の内容と対象の要件を確認できなければならない。'),
 ('zh-Hans', '应用程序必须保存每一项原始需求及其完整的修改历史。操作人员必须能够在没有网络连接的情况下导出整个项目，逐项检查记录的修改内容，并确认每次修改对应的需求和版本。'),
]

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def inventory(root):
    return {p.relative_to(root).as_posix(): sha(p.read_bytes())
            for p in sorted(root.rglob('*')) if p.is_file()}

def prepare():
    manifest, files, archive_sha = verify_package(ROOT / 'addon.zip')
    site = ROOT / 'site'
    site.mkdir()
    payload = {n[len('adapter/'):]: raw for n, raw in files.items() if n.startswith('adapter/')}
    for name, wheel in {'numpy': NUMPY['3.14'], 'py3langid': LANGID}.items():
        additions = wheel_files(files['wheels/' + wheel['filename']], name, wheel)
        assert not (payload.keys() & additions.keys())
        payload.update(additions)
    for name, raw in payload.items():
        p = site / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(raw)
        p.chmod(0o444)
    sys.path.insert(0, str(site))
    sys.path.insert(0, str(ROOT / 'fixtures-support'))
    from support.domain import domain_value
    from support.artifacts import artifact_bytes
    from support.model import configuration_file, put
    from support.relations import aid
    from specroad.model.paths import artifact_path
    from specroad.analyzers.subjects import request_from_project
    from specroad.analyzers.file_adapter import default_inputs
    project = ROOT / 'project'
    project.mkdir()
    (project / '.specroad').mkdir()
    configuration_file(project, project_id='resource-benchmark', project_name='Synthetic resource benchmark')
    cases = []
    for i in range(1000):
        language, sentence = TEXTS[i % len(TEXTS)]
        text = sentence
        while len(text) < 100:
            text += ' ' + sentence
        if i % 2 and len(text + ' ' + sentence) < 480:
            text += ' ' + sentence
        text += ' [' + str(i + 1).zfill(4) + ']'
        assert 100 <= len(text) <= 500
        value = domain_value('requirement', id=aid(number=i + 1), statement=text,
                             language=language, title='Synthetic resource case ' + str(i + 1))
        put(project, artifact_path('requirement', value['id'], 'SR'), artifact_bytes(value))
        cases.append({'id': value['id'], 'language_metadata': language,
                      'codepoints': len(text), 'utf8_sha256': sha(text.encode('utf-8'))})
    request = request_from_project(project, **default_inputs({}), analysis_id='benchmark:19v:1000:20261121')
    assert len(request.data['subjects']) == 1000
    (ROOT / 'request.json').write_bytes(request.canonical_bytes)
    fixture = {'format_version': 1, 'kind': 'synthetic-resource-fixture',
               'reviewed_language_corpus': False, 'classification_accuracy_asserted': False,
               'text_truncation': False, 'subjects': 1000, 'cases': cases,
               'min_codepoints': min(x['codepoints'] for x in cases),
               'max_codepoints': max(x['codepoints'] for x in cases),
               'request_sha256': sha(request.canonical_bytes), 'project_files': inventory(project)}
    (ROOT / 'fixture-manifest.json').write_text(json.dumps(fixture, sort_keys=True, ensure_ascii=False) + '\n')
    (ROOT / 'package-manifest.json').write_text(json.dumps(manifest, sort_keys=True) + '\n')
    (ROOT / 'site-manifest.json').write_text(json.dumps(inventory(site), sort_keys=True) + '\n')
    for p in project.rglob('*'):
        if p.is_file():
            p.chmod(0o444)
    (ROOT / 'scratch').mkdir()
    return {'archive_sha256': archive_sha, 'core_build': manifest['core_build'],
            'model_sha256': manifest['model']['sha256'], 'fixture_sha256': sha((ROOT / 'fixture-manifest.json').read_bytes()),
            'request_sha256': fixture['request_sha256'], 'subject_count': 1000,
            'min_codepoints': fixture['min_codepoints'], 'max_codepoints': fixture['max_codepoints']}

if __name__ == '__main__':
    print(json.dumps(prepare()), flush=True)
