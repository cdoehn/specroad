"""Measured parent: native request/transport/report validation, real worker."""
import hashlib
import json
import os
from pathlib import Path
import resource
import sys

run = Path(sys.argv[1]).resolve()
trial = Path(sys.argv[2]).resolve()
site = run / 'site'
sys.path.insert(0, str(site))
from specroad.analyzers.requests import AnalyzerRequest
from specroad.analyzers import _worker_process
from specroad.analyzers.worker_transport import execute
from specroad.runtime.resource_profiles import profile_targets

original_request = (run / 'request.json').read_bytes()
request = AnalyzerRequest(original_request)
subjects = sorted(request.data['subjects'], key=lambda row: row['subject_key'])
assert len(subjects) == 1000
assert all(100 <= len(row['value']) <= 500 for row in subjects)
_worker_process.BOOTSTRAP = ('MEASUREMENT_OUTPUT = ' + repr(str(trial / 'worker.json'))
    + '\n' + (run / 'measurement/worker.py').read_text())
native_run = _worker_process.run_process

def measured_run(command, **kwargs):
    environment = dict(kwargs['env'], LC_ALL='C', LANG='C', TZ='UTC',
                       TMPDIR=str(run / 'scratch'), TMP=str(run / 'scratch'),
                       TEMP=str(run / 'scratch'))
    kwargs['env'] = environment
    return native_run(['/usr/bin/time', '-v', '-o', str(trial / 'worker.time'),
                       *command], **kwargs)

_worker_process.run_process = measured_run
package = execute(request)
report = package.reports[0].data
counts = report['coverage']['counts']
assert report['run_status'] == 'complete'
assert counts['expected'] == counts['done'] + counts['undetermined'] == 1000
assert counts['open'] == counts['failed'] == 0
assert package.request.canonical_bytes == original_request
worker = json.loads((trial / 'worker.json').read_text())
assert worker['model_loads'] == 1
assert worker['ranked'] == [{'sha256': row['value_sha256'], 'codepoints': len(row['value'])}
                            for row in subjects]
assert report['engine']['model_sha256']['value'] == 'f4f4a2c3465ca1f081541037f9cac23021d68151c2f709c55ae5eedfca522963'
assert {s['subject_key'] for s in report['subjects']} == {s['subject_key'] for s in subjects}
(trial / 'report.json').write_bytes(package.canonical_bytes)
self_usage = resource.getrusage(resource.RUSAGE_SELF)
children = resource.getrusage(resource.RUSAGE_CHILDREN)
facts = {'pid': os.getpid(), 'ppid': os.getppid(), 'coverage': counts,
         'request_sha256': hashlib.sha256(original_request).hexdigest(),
         'report_sha256': hashlib.sha256(package.canonical_bytes).hexdigest(),
         'model_sha256': report['engine']['model_sha256']['value'],
         'engine': report['extensions']['specroad.engine_inventory'],
         'user_seconds': self_usage.ru_utime, 'system_seconds': self_usage.ru_stime,
         'self_maxrss_kib': self_usage.ru_maxrss,
         'waited_children_user_seconds': children.ru_utime,
         'waited_children_system_seconds': children.ru_stime,
         'resource_profile': profile_targets('standard', source='cli'),
         'cache': 'off', 'api_scope': 'full_adapter_via_native_transport_operator_bootstrap'}
(trial / 'parent.json').write_text(json.dumps(facts, sort_keys=True) + '\n')
print(json.dumps({'complete_subjects': 1000, 'model_loads': worker['model_loads'],
                  'report_sha256': facts['report_sha256']}), flush=True)

