"""One explicit resource measurement: warm-up plus five cold-process runs.

The observer is outside the measured process set. GNU time supplies lifetime
CPU/maximum-RSS counters; a separate /proc sampler records simultaneous RSS.
An uncertain RSS bound is reported as inconclusive, never as a pass.
"""
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import resource
import signal
import statistics
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent.parent
HOST = ROOT.parent.parent
RESULTS = ROOT / 'results'
sys.path.insert(0, str(ROOT / 'measurement'))
from prepare import prepare, inventory

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    with temporary.open('w') as stream:
        json.dump(value, stream, ensure_ascii=False, sort_keys=True)
        stream.write('\n'); stream.flush(); os.fsync(stream.fileno())
    os.replace(temporary, path)

def clock():
    return datetime.now(timezone.utc).isoformat()

def process(pid):
    p = Path('/proc') / str(pid)
    try:
        raw = (p / 'stat').read_text()
        cells = raw[raw.rfind(')') + 2:].split()
        return {'pid': pid, 'ppid': int(cells[1]), 'start_ticks': int(cells[19]),
                'user_ticks': int(cells[11]), 'system_ticks': int(cells[12]),
                'state': cells[0], 'comm': raw[raw.find('(') + 1:raw.rfind(')')]}
    except (FileNotFoundError, ProcessLookupError):
        return None

def ancestors():
    ids = set()
    pid = os.getpid()
    while pid and pid not in ids:
        ids.add(pid)
        row = process(pid)
        if row is None:
            break
        pid = row['ppid']
    return ids

def tree(root_pid):
    todo, rows = [root_pid], {}
    while todo:
        pid = todo.pop()
        if pid in rows:
            continue
        row = process(pid)
        if row is None:
            continue
        rows[pid] = row
        try:
            for task in (Path('/proc') / str(pid) / 'task').iterdir():
                try:
                    todo.extend(map(int, (task / 'children').read_text().split()))
                except (FileNotFoundError, ProcessLookupError):
                    pass
        except (FileNotFoundError, ProcessLookupError):
            pass
    return rows

def rss(pid):
    try:
        rows = (Path('/proc') / str(pid) / 'smaps_rollup').read_text().splitlines()
        line = next(row for row in rows if row.startswith('Rss:'))
        cells = line.split()
        if cells[2] != 'kB':
            raise ValueError('Unknown kernel RSS unit')
        return int(cells[1]) * 1024
    except (FileNotFoundError, ProcessLookupError, StopIteration):
        return None

def environment(excluded):
    competing = []
    markers = (b'pytest', b'run_apply_tests', b'attempt_supervisor', b'live_worker',
               b'specroad.analyzers', b'benchmark.py', b'test-host/runs')
    for p in Path('/proc').iterdir():
        if not p.name.isdigit() or int(p.name) in excluded:
            continue
        try:
            command = (p / 'cmdline').read_bytes()
            if any(marker in command for marker in markers):
                row = process(int(p.name))
                if row:
                    competing.append({'pid': row['pid'], 'comm': row['comm']})
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            pass
    throttling = {str(p): int(p.read_text()) for p in Path('/sys/devices/system/cpu').glob('cpu*/thermal_throttle/*throttle_count')}
    governors = {str(p.parent): p.read_text().strip() for p in Path('/sys/devices/system/cpu/cpufreq').glob('policy*/scaling_governor')}
    return {'time': clock(), 'swap': Path('/proc/swaps').read_text().splitlines()[1:],
            'governors': governors, 'thermal_throttle_counts': throttling,
            'competing_processes': competing, 'loadavg': Path('/proc/loadavg').read_text().strip()}

def qualified(row, baseline):
    return (not row['swap'] and not row['competing_processes']
            and row['governors'] == baseline['governors']
            and set(row['governors'].values()) == {'performance'}
            and bool(row['thermal_throttle_counts'])
            and row['thermal_throttle_counts'] == baseline['thermal_throttle_counts'])

def time_values(path):
    text = path.read_text()
    def field(label):
        match = re.search(r'^\s*' + re.escape(label) + r':\s*([0-9.]+)\s*$', text, re.M)
        if not match:
            raise ValueError('Missing GNU time field: ' + label)
        return float(match.group(1))
    return {'user_seconds': field('User time (seconds)'),
            'system_seconds': field('System time (seconds)'),
            'maxrss_bytes': int(field('Maximum resident set size (kbytes)')) * 1024,
            'exit_status': int(field('Exit status'))}

def trial(name, baseline, project_manifest):
    directory = RESULTS / name
    directory.mkdir()
    command = ['/usr/bin/time', '-v', '-o', str(directory / 'tree.time'),
               sys.executable, '-I', '-S', '-B', '-u', str(ROOT / 'measurement/parent.py'),
               str(ROOT), str(directory)]
    start = time.monotonic_ns()
    known = {}
    maximum = 0
    spans = []
    interval_gaps = []
    count = 0
    checks = []
    last = start
    errors = []
    with (directory / 'stdout.log').open('wb') as out, (directory / 'stderr.log').open('wb') as err:
        child = subprocess.Popen(command, cwd=ROOT / 'project', stdin=subprocess.DEVNULL,
                                 stdout=out, stderr=err, start_new_session=True)
        write(ROOT / 'progress.json', {'state': 'running', 'trial': name, 'started_at': clock(),
                                      'observer_pid': os.getpid(), 'measured_wrapper_pid': child.pid})
        try:
            with gzip.open(directory / 'rss-samples.jsonl.gz', 'wt', encoding='utf-8') as log:
                next_environment = 0
                while child.poll() is None:
                    sample_start = time.monotonic_ns()
                    rows = tree(child.pid)
                    measured = []
                    for pid, row in rows.items():
                        if row['comm'] == 'time' or pid == child.pid:
                            row['role'] = 'gnu-time-observer'
                        else:
                            try:
                                args = (Path('/proc') / str(pid) / 'cmdline').read_bytes().split(b'\0')
                            except (FileNotFoundError, ProcessLookupError):
                                continue
                            row['role'] = ('parent' if str(ROOT / 'measurement/parent.py').encode() in args
                                           else 'worker')
                            value = rss(pid)
                            if value is not None:
                                row['rss_bytes'] = value
                                measured.append(row)
                        known[(pid, row['start_ticks'])] = dict(row)
                    sample_end = time.monotonic_ns()
                    if measured:
                        total = sum(x['rss_bytes'] for x in measured)
                        maximum = max(maximum, total)
                        log.write(json.dumps({'start_ns': sample_start, 'end_ns': sample_end,
                                              'rss_bytes': total, 'processes': measured}, sort_keys=True) + '\n')
                        count += 1
                        spans.append(sample_end - sample_start)
                        interval_gaps.append(sample_start - last)
                        last = sample_start
                    if sample_end >= next_environment:
                        checks.append(environment(ancestors() | set(rows)))
                        next_environment = sample_end + 1_000_000_000
                    if sample_end - start > 7_200_000_000_000:
                        raise TimeoutError('Two-hour operator guard exceeded; workload is not passed')
                    time.sleep(0.01)
            code = child.wait()
        except BaseException:
            for pid in reversed(list(tree(child.pid))):
                try:
                    os.kill(pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            child.wait()
            raise
    wall = (time.monotonic_ns() - start) / 1e9
    if code != 0:
        write(directory / 'result.json', {'status': 'execution_failed', 'exit_code': code,
              'wall_seconds': wall, 'processes': list(known.values()), 'environment': checks})
        raise ValueError('Measured workload failed in ' + name + '; see preserved stderr and result')
    parent = json.loads((directory / 'parent.json').read_text())
    worker = json.loads((directory / 'worker.json').read_text())
    outer = time_values(directory / 'tree.time')
    inner = time_values(directory / 'worker.time')
    assert outer['exit_status'] == inner['exit_status'] == 0
    assert {x['pid'] for x in known.values() if x['role'] != 'gnu-time-observer'} == {parent['pid'], worker['pid']}
    assert count > 0
    assert inventory(ROOT / 'project') == project_manifest
    # Lifetime GNU-time peaks give a conservative bound even if a brief peak
    # falls between /proc samples. The outer maximum can include the worker;
    # adding the worker peak is deliberately conservative, never an RSS claim.
    upper = outer['maxrss_bytes'] + inner['maxrss_bytes']
    cpu = outer['user_seconds'] + outer['system_seconds']
    qualified_environment = all(qualified(row, baseline) for row in checks)
    memory_status = ('within_limit' if upper <= 512 * 1024**2 else
                     'observed_above_limit' if maximum > 512 * 1024**2 else 'inconclusive_upper_bound')
    result = {'status': 'measured', 'trial': name, 'wall_seconds': wall,
              'cpu_total_seconds': cpu, 'cpu_resolution_seconds': 0.01,
              'cpu_with_rounding_allowance_within_120_seconds': cpu + 0.02 <= 120,
              'parent_cpu_seconds': parent['user_seconds'] + parent['system_seconds'],
              'worker_cpu_seconds': worker['user_seconds'] + worker['system_seconds'],
              'sampled_simultaneous_rss_peak_bytes': maximum,
              'rss_conservative_upper_bound_bytes': upper, 'memory_status': memory_status,
              'gnu_time_tree': outer, 'gnu_time_worker': inner,
              'rss_sample_count': count, 'max_sample_read_span_ns': max(spans),
              'max_sample_interval_ns': max(interval_gaps), 'environment_qualified': qualified_environment,
              'environment': checks, 'processes': list(known.values()),
              'complete_subjects': 1000, 'model_loads': worker['model_loads'],
              'project_bytes_unchanged': True, 'parent': parent,
              'files_sha256': {p.name: sha(p) for p in sorted(directory.iterdir()) if p.is_file()}}
    write(directory / 'result.json', result)
    print(json.dumps({k: result[k] for k in ('trial', 'cpu_total_seconds', 'wall_seconds',
          'sampled_simultaneous_rss_peak_bytes', 'memory_status', 'environment_qualified')}), flush=True)
    return result

def main():
    os.umask(0o077)
    if sys.argv[1:] not in (['--prepare-only'], ['--run']):
        raise ValueError('Select --prepare-only or --run explicitly')
    def interrupted(signum, frame):
        raise KeyboardInterrupt('Operator signal ' + str(signum))
    for signum in (signal.SIGTERM, signal.SIGHUP):
        signal.signal(signum, interrupted)
    write(ROOT / 'progress.json', {'state': 'preparing', 'started_at': clock(), 'observer_pid': os.getpid()})
    inputs = json.loads((ROOT / 'operator-inputs.json').read_text())
    assert sha(Path(sys.executable)) == inputs['interpreter_sha256']
    assert platform.python_version() == inputs['interpreter_version']
    if sys.argv[1:] == ['--prepare-only']:
        prepared = prepare()
        write(ROOT / 'prepared.json', prepared)
    else:
        prepared = json.loads((ROOT / 'prepared.json').read_text())
        assert sha(ROOT / 'addon.zip') == prepared['archive_sha256']
        assert sha(ROOT / 'fixture-manifest.json') == prepared['fixture_sha256']
        assert sha(ROOT / 'request.json') == prepared['request_sha256']
        assert inventory(ROOT / 'site') == json.loads((ROOT / 'site-manifest.json').read_text())
    fixture = json.loads((ROOT / 'fixture-manifest.json').read_text())
    preflight = json.loads((HOST / 'platform.preflight.json').read_text())
    baseline = environment(ancestors())
    assert qualified(baseline, baseline), 'Reference host conditions no longer hold'
    assert Path('/proc/sys/kernel/random/boot_id').read_text().strip() == preflight['boot_id']
    assert (ROOT / 'project').stat().st_dev == (ROOT / 'project/.specroad').stat().st_dev == (ROOT / 'scratch').stat().st_dev
    platform_record = dict(preflight)
    platform_record.update(format_version=1, kind='operator-analyzer-benchmark-platform',
        python={'implementation': sys.implementation.name, 'version': platform.python_version(),
                'build': list(platform.python_build()), 'executable_sha256': sha(Path(sys.executable))},
        source_commit=inputs['source_commit'], source_result_sha256=inputs['source_result_sha256'],
        specroad_build=prepared['core_build'], model_sha256=prepared['model_sha256'],
        package_sha256=prepared['archive_sha256'], fixture_manifest_sha256=prepared['fixture_sha256'],
        measurement_scripts_sha256={p.name: sha(p) for p in sorted((ROOT / 'measurement').glob('*.py'))},
        setup_completed_at=clock(), baseline_environment=baseline,
        benchmark_run=False, acceptance_passed=False)
    write(ROOT / 'benchmark-platform.json', platform_record)
    print(json.dumps({'prepared': True, 'subjects': prepared['subject_count'],
                      'codepoint_range': [prepared['min_codepoints'], prepared['max_codepoints']],
                      'python': platform.python_version(), 'platform_sha256': sha(ROOT / 'benchmark-platform.json')}), flush=True)
    if sys.argv[1:] == ['--prepare-only']:
        write(ROOT / 'progress.json', {'state': 'ready', 'prepared_at': clock(),
                                     'subjects': 1000, 'benchmark_started': False})
        return
    RESULTS.mkdir()
    runs = [trial('warmup', baseline, fixture['project_files'])]
    for number in range(1, 6):
        runs.append(trial('run-' + str(number), baseline, fixture['project_files']))
    actual = runs[1:]
    limit_checks_pass = all(x['cpu_with_rounding_allowance_within_120_seconds']
                           and x['memory_status'] == 'within_limit'
                           and x['environment_qualified'] for x in actual)
    summary = {'format_version': 1, 'status': 'completed', 'completed_at': clock(),
               'scope': 'manual_real_adapter_resource_measurement_not_apply_gate_or_release',
               'source_result_sha256': inputs['source_result_sha256'], 'source_commit': inputs['source_commit'],
               'platform_sha256': sha(ROOT / 'benchmark-platform.json'),
               'fixture_manifest_sha256': sha(ROOT / 'fixture-manifest.json'),
               'measurement_scripts_sha256': platform_record['measurement_scripts_sha256'],
               'warmup_count': 1, 'measured_run_count': 5, 'subjects_per_run': 1000,
               'cpu_max_seconds': max(x['cpu_total_seconds'] for x in actual),
               'cpu_median_seconds': statistics.median(x['cpu_total_seconds'] for x in actual),
               'wall_median_seconds': statistics.median(x['wall_seconds'] for x in actual),
               'sampled_simultaneous_rss_max_bytes': max(x['sampled_simultaneous_rss_peak_bytes'] for x in actual),
               'rss_conservative_upper_bound_max_bytes': max(x['rss_conservative_upper_bound_bytes'] for x in actual),
               'measured_resource_limit_checks_passed': limit_checks_pass,
               'apply_gate_passed': False, 'release_approved': False, 'human_corpus_review_completed': False,
               'raw_results_sha256': {x['trial']: sha(RESULTS / x['trial'] / 'result.json') for x in runs},
               'observer_cpu_seconds': resource.getrusage(resource.RUSAGE_SELF).ru_utime + resource.getrusage(resource.RUSAGE_SELF).ru_stime}
    write(ROOT / 'summary.json', summary)
    write(ROOT / 'progress.json', {'state': 'completed', 'completed_at': clock(), 'summary_sha256': sha(ROOT / 'summary.json')})
    print(json.dumps(summary, sort_keys=True), flush=True)

if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        write(ROOT / 'progress.json', {'state': 'failed', 'failed_at': clock(),
              'error_type': type(error).__name__, 'message': str(error), 'observer_pid': os.getpid()})
        raise
